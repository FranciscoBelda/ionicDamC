export interface Componente {
  nombre: string;
  icono: string;
  ruta: string;
}
