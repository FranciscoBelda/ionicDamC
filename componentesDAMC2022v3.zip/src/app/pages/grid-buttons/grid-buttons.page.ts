import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-grid-buttons',
  templateUrl: './grid-buttons.page.html',
  styleUrls: ['./grid-buttons.page.scss'],
})
export class GridButtonsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
